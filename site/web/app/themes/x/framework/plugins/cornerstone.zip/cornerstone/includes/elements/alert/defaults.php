<?php

/**
 * Element Defaults: Alert
 */

return array(
	'id'      => '',
	'class'   => '',
	'style'   => '',
	'heading' => '',
	'type'    => 'success',
	'close'   => false
);