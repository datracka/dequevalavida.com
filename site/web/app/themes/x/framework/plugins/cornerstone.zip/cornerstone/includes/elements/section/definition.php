<?php

/**
 * Element Definition: Section
 */

class CSE_Section {

	public function ui() {
		return array(
      'title'       => __( 'Section', csl18n() ),
    );
	}

	public function flags() {
		return array( 'context' => '_layout' );
	}

	public function _layout_defaults() {
		return array(
			'elements' => array( array( '_type' => 'row' ) )
		);
	}

	public function register_shortcode() {
  	return false;
  }

	public function update_build_shortcode_atts( $atts ) {

		unset( $atts['title'] );
		$atts = Cornerstone_Control_Mixins::legacy_injections( $atts );

		return $atts;

	}
}