<?php
class Cornerstone_Control_Choose extends Cornerstone_Control {
	protected $default_options = array(
		'columns' => 2,
		'choices' => array()
  );
}